package game;

import java.io.InputStream;

public class scanner extends GuessOrSink {
    public scanner(InputStream in) {
        super();
    }
}
