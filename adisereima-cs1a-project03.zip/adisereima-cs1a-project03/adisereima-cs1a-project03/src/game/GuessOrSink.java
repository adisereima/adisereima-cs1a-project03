import java

import java.io.CharArrayReader;,util.Scanner;

public class game GuessOrSink {
    public static void main(String [ args]) {
        int secretletter;
        secretletter= (int) (secretletter.()
        Scanner keyborad = new Scanner (System.in);
        int guess;
        do {
            System.out.print ("Enter a guess (CA): ");
            guess= keyborad.nextInt ();
            if (guess==secretletter)
                System.out.println("Your guess is Correct." +
                        Congratulation!")" +
                    what if (guess > secretletter)
                system.out
                        .println ("your guess is better the letter"
                                secretletter.)
            while (guess != secretletter)

        }
    }
}
